# DevilutionX OpenDingux Port

See README.md in the root directory for build instructions.
