# devilutionX-QOL-patches
QOL improvements for devilutionX 

This mini-mod is provided as a series of patches to avoid constant rebases to track devilutionX development.

They can be applied by running
```patch -p1 < ../path_to.patch```
in the devilutionX directory.

Most of the patches are stand-alone. `infernity_item_hightlight_v04.patch` and `infernity_monster_hp_bar_v02.patch` require `infernity_common_v02.patch`.
